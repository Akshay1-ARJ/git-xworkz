import tensorflow as tf

import cv2
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt

from keras.models import load_model

import tkinter as tk
import os
from matplotlib import pyplot
from matplotlib.image import imread
import glob
 
frameWidth = 640
frameHeight = 480
cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
cap.set(3, frameWidth)
cap.set(4, frameHeight)
cap.set(10,150)
index=0

label_map = pd.read_csv("balanced.txt", 
                        delimiter = ' ', 
                        index_col=0, 
                        header=None, 
                        squeeze=True)                 #load the label valuesn i.e 0-0 10-A.....46-t
label_dictionary = {}                                     #storing label values in dictionary
for index, label in enumerate(label_map):
    label_dictionary[index] = chr(label)
    
IMG_SIZE=28
folder = 'test/'

model = load_model('my_model.h5')                        # Load best model

file = open('recognizedtextdk.txt','a')                     #open a file to write the recognized characters
#file.write("dundayya kallimath\n")
file.write("Recognized text is\n")

kernel = np.ones((5, 5), np.uint8)

myColors = [[5,107,0,19,255,255],
            [169,100,100,189,255,255],
            [57,76,0,100,255,255],
            [90,48,0,118,255,255],
           [110,100,100,130,255,255]]
myColorValues = [[51,153,255],                             ## BGR
                 [0,0,255],
                 [0,255,0],
                 [255,0,0],
                [255,255,255]]
 
myPoints =  []                                              ## [x , y , colorId ]

def selectpen():
    root = tk.Tk()
    v = tk.IntVar()
    tk.Label(root, text="""Choose Pen""",justify = tk.LEFT,padx = 20).pack()
    tk.Radiobutton(root, text="Safron",padx = 20, variable=v, value=0).pack(anchor=tk.W)
    tk.Radiobutton(root, text="red",padx = 20, variable=v, value=1).pack(anchor=tk.W)
    tk.Radiobutton(root, text="Green",padx = 20, variable=v, value=2).pack(anchor=tk.W)
    tk.Radiobutton(root, text="Blue",padx = 20, variable=v, value=3).pack(anchor=tk.W)
    root.mainloop()
    return v.get()

def findColor(img,myColors,myColorValues,a):
    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    count = 0
    newPoints=[]
    color=myColors[a]
    lower = np.array(color[0:3])
    upper = np.array(color[3:6])
    mask = cv2.inRange(imgHSV,lower,upper)
    mask = cv2.erode(mask, kernel, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.dilate(mask, kernel, iterations=1)
    x,y=getContours(mask)
    cv2.circle(imgResult,(x,y),15,myColorValues[a],cv2.FILLED)
    if x!=0 and y!=0:
        newPoints.append([x,y,count])
    #count +=1
        #cv2.imshow(str(color[0]),mask)
    return newPoints
 
def getContours(img):
    contours,hierarchy = cv2.findContours(img,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    x,y,w,h = 0,0,0,0
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area>500:
            #cv2.drawContours(imgResult, cnt, -1, (255, 0, 0), 3)
            peri = cv2.arcLength(cnt,True)
            approx = cv2.approxPolyDP(cnt,0.02*peri,True)
            x, y, w, h = cv2.boundingRect(approx)
    return x+w//2,y
 
def drawOnCanvas(myPoints,myColorValues,a):
    for point in myPoints:
        cv2.circle(imgResult, (point[0], point[1]), 10, myColorValues[a], cv2.FILLED)
        cv2.circle(paintWindow, (point[0], point[1]), 10, myColorValues[4], cv2.FILLED)
        
def seperatesplit():
    index=0
    fl=glob.glob(os.path.join(folder,"*"))
    for f in fl:
        os.remove(f)
    img = cv2.resize(paintWindow, (frameWidth, frameHeight))
    cv2.imshow("Result", img)
    name=folder +'dk.'+str(index)+'.png'
    print('creating...'+name)
    cv2.imwrite(name,img)
    img=cv2.imread(folder+'dk.0.png')
    imgray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    ret,thresh=cv2.threshold(imgray,127,255,0)
    contours,hierarchy=cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
    #cv2.drawContours(img,contours,3,(255,0,0),4)
    i=1
    for cnt in contours:
        if cv2.contourArea(cnt)<100000:
            (x,y,w,h)=cv2.boundingRect(cnt)
            cv2.rectangle(img,(x-30,y-50),(x+w+30,y+h+30),(0,255,0),4)
            plt.imshow(imgray)
            img2=img[y:y+h,x:x+w]          #x:x+h,y:y+w
            name=folder +'dk.'+str(i)+'.png'
            cv2.imwrite(name,img2)
            i=i+1
            

def predict():                                               #folder where our split images are stored
    a='test'
    m=0
    n=0
    n=len(glob.glob1(a,"*.png"))
    print(n)
    # fetch first few images
    for i in range(1,n):
        # define subplot
        pyplot.subplot(330 + 1 + i)
        x= folder + 'dk.' + str(i) + '.png'
        # load image pixels
        image = imread(x)
        # plot raw pixel data
        #pyplot.imshow(image)
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        resized=cv2.resize(gray,(28,28),interpolation=cv2.INTER_AREA)
        newimg=tf.keras.utils.normalize(resized,axis=1)
        newimg=np.array(newimg).reshape(-1,IMG_SIZE,IMG_SIZE,1)
        pred=model.predict(newimg)
        pyplot.imshow(image)
        plt.title(label_dictionary[np.argmax(pred)])
        print(label_dictionary[np.argmax(pred)])
        d=label_dictionary[np.argmax(pred)]
        file.write(d +" ")            #file writing
        cv2.putText(Output,d,(50+m,50+n),cv2.FONT_HERSHEY_SIMPLEX,1,(255,0,0),2,cv2.LINE_AA)     #frame writing
        cv2.imshow("OutputFrame", Output)
        m=m+50
 
a=selectpen()
print(a)
while True:
    success, img = cap.read()
    img = cv2.flip(img, 1)
    if img is None:
        break
    imgResult = img.copy()
    newPoints = findColor(img, myColors,myColorValues,a)
    paintWindow = np.zeros((471, 636, 3))
    cv2.namedWindow('Writing', cv2.WINDOW_AUTOSIZE)
    Output = np.zeros((471, 636, 3)) + 255
    cv2.namedWindow('OutputFrame', cv2.WINDOW_AUTOSIZE)
    if len(newPoints)!=0:
        for newP in newPoints:
            myPoints.append(newP)
    if len(myPoints)!=0:
        drawOnCanvas(myPoints,myColorValues,a)
 
    
    key = cv2.waitKey(1)
    
    if key & 0xFF == ord("c"):                                                 #clear the screen
        myPoints=[]
        
    if key & 0xFF == ord("p"):                                                 #clear the screen
        seperatesplit()
        predict()
        index+=1
        
    if key & 0xFF == ord("q"):
        break
    
    cv2.imshow("Result", imgResult)
    cv2.imshow("Writing", paintWindow)
    
    

# Release the camera and all resources
cap.release()
cv2.destroyAllWindows()
file.close
