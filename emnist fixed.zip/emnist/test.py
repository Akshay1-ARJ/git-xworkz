import numpy as np 
a=np.arange(16).reshape(4,4) 
b=np.insert(a,2,[5,5,5,5],axis=1) 
print(b)